import React from 'react';
import { createRoot } from 'react-dom/client';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import Login from './pages/Login';
import Signup from './pages/Signup';
import Stores from './pages/Stores';
import AdminDashboard from './pages/admin/Dashboard';
import OwnerDashboard from './pages/owner/Dashboard';
import { getToken, getRole } from './lib/auth';

const qc = new QueryClient();

function Protected({ children }: { children: JSX.Element }){
  return getToken() ? children : <Navigate to="/login" replace />;
}
function RoleGuard({ roles, children }: { roles: string[], children: JSX.Element }){
  return roles.includes(getRole()||'') ? children : <div>Unauthorized</div>;
}

const App = () => (
  <QueryClientProvider client={qc}>
    <BrowserRouter>
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route path="/signup" element={<Signup />} />
        <Route path="/stores" element={<Protected><Stores /></Protected>} />
        <Route path="/admin" element={<Protected><RoleGuard roles={["SYSTEM_ADMIN"]}><AdminDashboard /></RoleGuard></Protected>} />
        <Route path="/owner" element={<Protected><RoleGuard roles={["STORE_OWNER"]}><OwnerDashboard /></RoleGuard></Protected>} />
        <Route path="*" element={<Navigate to="/stores" replace />} />
      </Routes>
    </BrowserRouter>
  </QueryClientProvider>
);

createRoot(document.getElementById('root')!).render(<App />);
