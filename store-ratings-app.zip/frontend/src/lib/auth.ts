export const getToken = () => localStorage.getItem('access_token');
export const setToken = (t: string) => localStorage.setItem('access_token', t);
export const setRole = (r: string) => localStorage.setItem('role', r);
export const getRole = () => localStorage.getItem('role');
export const clearAuth = () => { localStorage.removeItem('access_token'); localStorage.removeItem('role'); };
