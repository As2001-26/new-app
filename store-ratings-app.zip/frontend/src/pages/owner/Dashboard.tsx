import React from 'react';
import { useQuery } from '@tanstack/react-query';
import API from '@/lib/api';

export default function OwnerDashboard(){
  const { data: store } = useQuery({ queryKey:['owner-store'], queryFn: async()=> (await API.get('/owner/store')).data });
  const { data: listing } = useQuery({ queryKey:['owner-ratings'], queryFn: async()=> (await API.get('/owner/store/ratings')).data });
  return (<div style={{maxWidth:900, margin:'20px auto'}}>
    <h2>Owner Dashboard</h2>
    {store && <div><b>{store.name}</b> – Avg: {Number(store.avgRating||0).toFixed(1)} ({store.ratingsCount})</div>}
    <h3>Raters</h3>
    <ul>
      {listing?.ratings?.map((r:any)=>(<li key={r.id}>{r.user?.name} ({r.user?.email}) – {r.score}</li>))}
    </ul>
  </div>);
}
