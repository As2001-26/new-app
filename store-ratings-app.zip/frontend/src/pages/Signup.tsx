import React, { useState } from 'react';
import API from '@/lib/api';
import { Link, useNavigate } from 'react-router-dom';

export default function Signup(){
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [address, setAddress] = useState('');
  const [password, setPassword] = useState('');
  const [errors, setErrors] = useState<string[]>([]);
  const nav = useNavigate();

  async function onSubmit(e: React.FormEvent){
    e.preventDefault();
    try{
      const { data } = await API.post('/auth/signup', { name, email, address, password });
      if (data?.id) nav('/login');
    }catch(e:any){
      const err = e?.response?.data;
      setErrors(err?.errors || [err?.message || 'Signup failed']);
    }
  }
  return (<div style={{maxWidth:520, margin:'40px auto'}}>
    <h2>Sign up</h2>
    <form onSubmit={onSubmit}>
      <input placeholder="Full Name (20-60)" value={name} onChange={e=>setName(e.target.value)} /><br/>
      <input placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)} /><br/>
      <input placeholder="Address (<=400)" value={address} onChange={e=>setAddress(e.target.value)} /><br/>
      <input placeholder="Password" type="password" value={password} onChange={e=>setPassword(e.target.value)} /><br/>
      <button type="submit">Create account</button>
    </form>
    {errors.map((er,i)=>(<div key={i} style={{color:'red'}}>{er}</div>))}
    <div><Link to="/login">Back to login</Link></div>
  </div>);
}
