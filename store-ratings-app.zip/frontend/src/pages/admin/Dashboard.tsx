import React from 'react';
import { useQuery } from '@tanstack/react-query';
import API from '@/lib/api';
export default function AdminDashboard(){
  const { data } = useQuery({ queryKey:['admin-stats'], queryFn: async()=> (await API.get('/admin/dashboard')).data });
  return (<div style={{maxWidth:900, margin:'20px auto'}}>
    <h2>Admin Dashboard</h2>
    <div style={{display:'grid', gridTemplateColumns:'repeat(3,1fr)', gap:12}}>
      <div style={{border:'1px solid #ddd', padding:12}}><div>Total Users</div><div style={{fontSize:28}}>{data?.totalUsers ?? '-'}</div></div>
      <div style={{border:'1px solid #ddd', padding:12}}><div>Total Stores</div><div style={{fontSize:28}}>{data?.totalStores ?? '-'}</div></div>
      <div style={{border:'1px solid #ddd', padding:12}}><div>Total Ratings</div><div style={{fontSize:28}}>{data?.totalRatings ?? '-'}</div></div>
    </div>
  </div>);
}
