import React, { useState } from 'react';
import { useQuery, useQueryClient, useMutation } from '@tanstack/react-query';
import API from '@/lib/api';

function Rating({ storeId, myScore }:{storeId:string, myScore?:number}){
  const qc = useQueryClient();
  const mut = useMutation({ mutationFn: (score:number)=> API.post('/ratings', { storeId, score }), 
    onSuccess:()=> qc.invalidateQueries({queryKey:['stores']}) });
  return (<div>
    {[1,2,3,4,5].map(n => <button key={n} onClick={()=>mut.mutate(n)}>{n <= (myScore||0)?'★':'☆'}</button>)}
    {myScore ? <span> Your rating: {myScore}</span> : null}
  </div>);
}

export default function Stores(){
  const [q, setQ] = useState('');
  const { data } = useQuery({ queryKey:['stores', q], queryFn: async()=> (await API.get('/stores', { params: { search: q }})).data });
  return (<div style={{maxWidth:800, margin:'20px auto'}}>
    <h2>Stores</h2>
    <input placeholder="Search" value={q} onChange={e=>setQ(e.target.value)} />
    <div>
      {data?.data?.map((s:any)=>(<div key={s.id} style={{border:'1px solid #ccc', padding:12, marginTop:8}}>
        <div style={{display:'flex', justifyContent:'space-between'}}>
          <div>
            <div><b>{s.name}</b></div>
            <div>{s.address}</div>
          </div>
          <div>Overall: {Number(s.avgRating||0).toFixed(1)} ({s.ratingsCount})</div>
        </div>
        <Rating storeId={s.id} myScore={s.myRating?.score} />
      </div>))}
    </div>
  </div>);
}
