import React, { useState } from 'react';
import API from '@/lib/api';
import { setToken, setRole } from '@/lib/auth';
import { useNavigate, Link } from 'react-router-dom';

export default function Login(){
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [err, setErr] = useState('');
  const nav = useNavigate();
  async function onSubmit(e: React.FormEvent){
    e.preventDefault();
    try{
      const { data } = await API.post('/auth/login', { email, password });
      setToken(data.accessToken); setRole(data.user.role);
      nav('/stores');
    }catch(e:any){ setErr(e?.response?.data?.message || 'Login failed'); }
  }
  return (<div style={{maxWidth:420, margin:'40px auto'}}>
    <h2>Login</h2>
    <form onSubmit={onSubmit}>
      <input placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)} /><br/>
      <input placeholder="Password" type="password" value={password} onChange={e=>setPassword(e.target.value)} /><br/>
      <button type="submit">Login</button>
      {err && <div style={{color:'red'}}>{err}</div>}
    </form>
    <div><Link to="/signup">Create account</Link></div>
  </div>);
}
