# Store Ratings Frontend (React + Vite + TS)

## Setup
1. `npm install`
2. Create `.env` with `VITE_API_URL=http://localhost:3000`
3. `npm run dev`
