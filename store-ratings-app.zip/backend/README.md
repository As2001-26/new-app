# Store Ratings API (Express + Sequelize + MySQL)

## Setup
1. Copy `.env.example` to `.env` and fill values (DB + JWT_SECRET).
2. Install deps: `npm install`
3. Start dev: `npm run dev`

The app auto-syncs models to DB for dev/demo. For production, use migrations.

## Endpoints
- POST /auth/signup
- POST /auth/login
- POST /auth/change-password
- POST /admin/users  (SYSTEM_ADMIN)
- GET  /admin/users  (filters via query)
- POST /admin/stores (SYSTEM_ADMIN; ownerId must be STORE_OWNER)
- GET  /admin/stores
- GET  /admin/dashboard
- GET  /stores            (requires auth header; attaches myRating if available)
- POST /ratings           (auth) { storeId, score }
- GET  /owner/store       (STORE_OWNER)
- GET  /owner/store/ratings (STORE_OWNER)
