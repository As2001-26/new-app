import { Router } from 'express';
import { authRequired } from '../middleware/auth.js';
import { listPublicStores } from '../controllers/store.controller.js';
const r = Router();
// Allow both authenticated and unauthenticated, but attach user when present
r.get('/', authRequired, listPublicStores);
export default r;
