import { Router } from 'express';
import { authRequired } from '../middleware/auth.js';
import { requireRoles } from '../middleware/roles.js';
import { ownerStore, ownerRatings } from '../controllers/owner.controller.js';
const r = Router();
r.use(authRequired, requireRoles('STORE_OWNER'));
r.get('/store', ownerStore);
r.get('/store/ratings', ownerRatings);
export default r;
