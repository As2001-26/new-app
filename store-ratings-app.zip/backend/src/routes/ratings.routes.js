import { Router } from 'express';
import { authRequired } from '../middleware/auth.js';
import { upsertRating } from '../controllers/rating.controller.js';
const r = Router();
r.post('/', authRequired, upsertRating);
export default r;
