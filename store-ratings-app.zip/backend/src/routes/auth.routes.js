import { Router } from 'express';
import { signup, login, changePassword } from '../controllers/auth.controller.js';
import { authRequired } from '../middleware/auth.js';
const r = Router();
r.post('/signup', signup);
r.post('/login', login);
r.post('/change-password', authRequired, changePassword);
export default r;
