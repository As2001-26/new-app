export default (sequelize, DataTypes) => {
  const Store = sequelize.define('Store', {
    id: { type: DataTypes.STRING(36), primaryKey: true, defaultValue: DataTypes.UUIDV4 },
    name: { type: DataTypes.STRING(100), allowNull: false },
    email: { type: DataTypes.STRING(255), allowNull: false, unique: true, validate: { isEmail: true } },
    address: { type: DataTypes.STRING(400), allowNull: false },
    ownerId: { type: DataTypes.STRING(36), allowNull: false },
    avgRating: { type: DataTypes.FLOAT, allowNull: false, defaultValue: 0 },
    ratingsCount: { type: DataTypes.INTEGER, allowNull: false, defaultValue: 0 }
  }, { tableName: 'Stores' });
  return Store;
};
