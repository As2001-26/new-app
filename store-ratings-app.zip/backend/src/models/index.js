import { Sequelize, DataTypes } from 'sequelize';

const {
  DB_HOST, DB_PORT, DB_USER, DB_PASS, DB_NAME
} = process.env;

export const sequelize = new Sequelize(DB_NAME, DB_USER, DB_PASS, {
  host: DB_HOST,
  port: DB_PORT,
  dialect: 'mysql',
  logging: false
});

import userModel from './user.model.js';
import storeModel from './store.model.js';
import ratingModel from './rating.model.js';

export const User = userModel(sequelize, DataTypes);
export const Store = storeModel(sequelize, DataTypes);
export const Rating = ratingModel(sequelize, DataTypes);

// Associations
User.hasMany(Store, { foreignKey: 'ownerId' });
Store.belongsTo(User, { as: 'owner', foreignKey: 'ownerId' });

User.hasMany(Rating, { foreignKey: 'userId' });
Rating.belongsTo(User, { foreignKey: 'userId' });

Store.hasMany(Rating, { foreignKey: 'storeId' });
Rating.belongsTo(Store, { foreignKey: 'storeId' });

// Unique composite for ratings
Rating.addHook('afterSync', async () => {
  // Ensure composite unique via raw SQL if not exists (idempotent attempt)
  await sequelize.query('CREATE UNIQUE INDEX IF NOT EXISTS ratings_user_store_unique ON Ratings (userId, storeId)');
});
