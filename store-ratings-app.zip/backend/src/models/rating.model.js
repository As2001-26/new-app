export default (sequelize, DataTypes) => {
  const Rating = sequelize.define('Rating', {
    id: { type: DataTypes.STRING(36), primaryKey: true, defaultValue: DataTypes.UUIDV4 },
    userId: { type: DataTypes.STRING(36), allowNull: false },
    storeId: { type: DataTypes.STRING(36), allowNull: false },
    score: { type: DataTypes.INTEGER, allowNull: false, validate: { min: 1, max: 5 } }
  }, { tableName: 'Ratings' });
  return Rating;
};
