import express from 'express';
import helmet from 'helmet';
import cors from 'cors';
import { sequelize } from './models/index.js';
import authRoutes from './routes/auth.routes.js';
import adminRoutes from './routes/admin.routes.js';
import storeRoutes from './routes/stores.routes.js';
import ratingRoutes from './routes/ratings.routes.js';
import ownerRoutes from './routes/owner.routes.js';

const app = express();
app.use(helmet());
app.use(cors());
app.use(express.json());

app.get('/', (req,res)=> res.json({ ok: true, service: 'store-ratings-api' }));

app.use('/auth', authRoutes);
app.use('/admin', adminRoutes);
app.use('/stores', storeRoutes);
app.use('/ratings', ratingRoutes);
app.use('/owner', ownerRoutes);

// DB connect & sync minimal (for dev/demo)
await sequelize.authenticate();
await sequelize.sync();

export default app;
