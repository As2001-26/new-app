import { Rating, Store } from '../models/index.js';

async function recomputeStore(storeId) {
  const ratings = await Rating.findAll({ where: { storeId } });
  const count = ratings.length;
  const avg = count ? ratings.reduce((a,b)=>a+b.score,0)/count : 0;
  await Store.update({ ratingsCount: count, avgRating: avg }, { where: { id: storeId } });
}

export const upsertRating = async (req, res) => {
  const userId = req.user.sub;
  const { storeId, score } = req.body;
  if (!storeId || !Number.isInteger(score) || score < 1 || score > 5) return res.status(400).json({ message: 'Invalid payload' });
  const existing = await Rating.findOne({ where: { userId, storeId } });
  if (existing) {
    await existing.update({ score });
  } else {
    await Rating.create({ userId, storeId, score });
  }
  await recomputeStore(storeId);
  res.json({ message: 'Saved' });
};
