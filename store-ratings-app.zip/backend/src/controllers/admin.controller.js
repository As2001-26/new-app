import { User, Store, Rating } from '../models/index.js';
import { hash } from '../utils/bcrypt.js';

export const createUser = async (req, res) => {
  const { name, email, address, password, role } = req.body;
  if (!name || name.length < 20 || name.length > 60) return res.status(400).json({ message: 'Invalid name' });
  if (!address || address.length > 400) return res.status(400).json({ message: 'Invalid address' });
  if (!email || !/\S+@\S+\.\S+/.test(email)) return res.status(400).json({ message: 'Invalid email' });
  if (!['SYSTEM_ADMIN','NORMAL_USER','STORE_OWNER'].includes(role)) return res.status(400).json({ message: 'Invalid role' });
  const exists = await User.findOne({ where: { email } });
  if (exists) return res.status(409).json({ message: 'Email exists' });
  const passwordHash = await hash(password || 'Admin@123');
  const user = await User.create({ name, email, address, role, passwordHash });
  res.status(201).json(user);
};

export const listUsers = async (req, res) => {
  const { name, email, address, role, sort = 'name:asc' } = req.query;
  const where = {};
  if (name) where.name = { [Symbol.for('like')]: `%${name}%` };
  if (email) where.email = { [Symbol.for('like')]: `%${email}%` };
  if (address) where.address = { [Symbol.for('like')]: `%${address}%` };
  if (role) where.role = role;
  const [field, dir] = sort.split(':');
  const users = await User.findAll({ where, order: [[field, dir?.toUpperCase()==='DESC'?'DESC':'ASC']] });
  res.json(users);
};

export const createStore = async (req, res) => {
  const { name, email, address, ownerId } = req.body;
  if (!name || !email || !address || !ownerId) return res.status(400).json({ message: 'Missing fields' });
  const owner = await User.findByPk(ownerId);
  if (!owner || owner.role !== 'STORE_OWNER') return res.status(400).json({ message: 'ownerId must be a STORE_OWNER' });
  const store = await Store.create({ name, email, address, ownerId });
  res.status(201).json(store);
};

export const listStores = async (req, res) => {
  const { name, email, address, sort = 'avgRating:desc' } = req.query;
  const where = {};
  if (name) where.name = { [Symbol.for('like')]: `%${name}%` };
  if (email) where.email = { [Symbol.for('like')]: `%${email}%` };
  if (address) where.address = { [Symbol.for('like')]: `%${address}%` };
  const [field, dir] = sort.split(':');
  const stores = await Store.findAll({ where, order: [[field, dir?.toUpperCase()==='ASC'?'ASC':'DESC']] });
  res.json(stores);
};

export const dashboardTotals = async (_req, res) => {
  const [users, stores, ratings] = await Promise.all([
    User.count(),
    Store.count(),
    Rating.count()
  ]);
  res.json({ totalUsers: users, totalStores: stores, totalRatings: ratings });
};
