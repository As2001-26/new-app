import { Store, Rating } from '../models/index.js';
export const listPublicStores = async (req, res) => {
  const { search, name, address, sort='avgRating:desc' } = req.query;
  const where = {};
  const like = (v) => ({ [Symbol.for('like')]: `%${v}%` });
  if (search) Object.assign(where, { name: like(search) }); // simple search example
  if (name) where.name = like(name);
  if (address) where.address = like(address);
  const [field, dir] = sort.split(':');
  const data = await Store.findAll({ order: [[field, (dir||'DESC').toUpperCase()]] });
  // Add myRating if logged in
  let userId = req.user?.sub;
  if (userId) {
    const ratings = await Rating.findAll({ where: { userId } });
    const map = new Map(ratings.map(r=>[r.storeId, r]));
    const enriched = data.map(s => ({ ...s.toJSON(), myRating: map.get(s.id) || null }));
    return res.json({ data: enriched });
  }
  res.json({ data });
};
