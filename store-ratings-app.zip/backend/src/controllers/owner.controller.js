import { Store, Rating, User } from '../models/index.js';
export const ownerStore = async (req, res) => {
  const store = await Store.findOne({ where: { ownerId: req.user.sub } });
  if (!store) return res.status(404).json({ message: 'No store for owner' });
  return res.json(store);
};
export const ownerRatings = async (req, res) => {
  const store = await Store.findOne({ where: { ownerId: req.user.sub } });
  if (!store) return res.status(404).json({ message: 'No store for owner' });
  const ratings = await Rating.findAll({ where: { storeId: store.id }, order: [['createdAt','DESC']] });
  const userIds = ratings.map(r=>r.userId);
  const users = await User.findAll({ where: { id: userIds } });
  const map = new Map(users.map(u=>[u.id, u]));
  const data = ratings.map(r=>({ ...r.toJSON(), user: map.get(r.userId)?.toJSON() }));
  res.json({ storeId: store.id, avgRating: store.avgRating, ratingsCount: store.ratingsCount, ratings: data });
};
