import jwt from 'jsonwebtoken';
import { User } from '../models/index.js';
import { validateSignup } from '../utils/validators.js';
import { hash, compare } from '../utils/bcrypt.js';

export const signup = async (req, res) => {
  const { name, email, address, password } = req.body;
  const errors = validateSignup({ name, email, address, password });
  if (errors.length) return res.status(400).json({ errors });
  const exists = await User.findOne({ where: { email } });
  if (exists) return res.status(409).json({ message: 'Email already registered' });
  const passwordHash = await hash(password);
  const user = await User.create({ name, email, address, passwordHash, role: 'NORMAL_USER' });
  return res.status(201).json({ id: user.id, email: user.email });
};

export const login = async (req, res) => {
  const { email, password } = req.body;
  const user = await User.findOne({ where: { email } });
  if (!user) return res.status(401).json({ message: 'Invalid credentials' });
  const ok = await compare(password, user.passwordHash);
  if (!ok) return res.status(401).json({ message: 'Invalid credentials' });
  const token = jwt.sign({ sub: user.id, role: user.role, email: user.email }, process.env.JWT_SECRET, { expiresIn: '1h' });
  return res.json({ accessToken: token, user: { id: user.id, role: user.role, name: user.name, email: user.email } });
};

export const changePassword = async (req, res) => {
  const { currentPassword, newPassword } = req.body;
  if (!newPassword) return res.status(400).json({ message: 'New password required' });
  const user = await User.findByPk(req.user.sub);
  if (!user) return res.status(404).json({ message: 'User not found' });
  const ok = await compare(currentPassword || '', user.passwordHash);
  if (!ok) return res.status(400).json({ message: 'Current password incorrect' });
  const passwordHash = await hash(newPassword);
  await user.update({ passwordHash });
  return res.json({ message: 'Password updated' });
};
