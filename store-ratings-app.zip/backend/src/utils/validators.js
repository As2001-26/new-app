
export const passwordRegex = /^(?=.*[A-Z])(?=.*[!@#$%^&*()_+\-={}[\]|:;"'<>,.?/]).{8,16}$/;

export function validateSignup({ name, email, address, password }) {
  const errors = [];
  if (!name || name.length < 20 || name.length > 60) errors.push('Name must be 20-60 characters.');
  if (!address || address.length > 400) errors.push('Address must be ≤ 400 characters.');
  if (!email || !/^\S+@\S+\.\S+$/.test(email)) errors.push('Invalid email.');
  if (!passwordRegex.test(password || '')) errors.push('Password must be 8-16 chars, include 1 uppercase & 1 special.');
  return errors;
}
