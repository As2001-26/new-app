import bcrypt from 'bcryptjs';
export const hash = (plain) => bcrypt.hash(plain, 12);
export const compare = (plain, hashed) => bcrypt.compare(plain, hashed);
